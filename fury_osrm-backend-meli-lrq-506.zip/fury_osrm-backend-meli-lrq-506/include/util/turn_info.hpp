#ifndef TURN_INFO_HPP
#define TURN_INFO_HPP

namespace osrm
{
namespace util
{
struct TurnInfo
{
  public:
    TurnInfo() : h_enters(0), h_exits(0), a_enters(0), a_exits(0), s_enters(0), s_exits(0) {}
    TurnInfo(int h_enters, int h_exits, int a_enters, int a_exits, int s_enters, int s_exits)
        : h_enters(h_enters), h_exits(h_exits), a_enters(a_enters), a_exits(a_exits),
          s_enters(s_enters), s_exits(s_exits)
    {
    }

    int h_enters;
    int h_exits;
    int a_enters;
    int a_exits;
    int s_enters;
    int s_exits;
};
} // namespace util
} // namespace osrm

#endif // TURN_INFO_HPP